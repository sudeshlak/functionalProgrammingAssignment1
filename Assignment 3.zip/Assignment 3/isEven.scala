object isEven {
  
	def main(args:Array[String]){
		println("Enter a Number:");
		var n = scala.io.StdIn.readInt();
		

		printf("%d is even -%b",n,isEven(n));
		

}

		def isEven(x:Int):Boolean={
			if(x==0){
			return true;
		
}
			else if(x==1){
			return false;
}
			else{
			return isEven(x-2);
}


}

}