object addition {
	def main(args:Array[String]){
		println("Enter a Number :");
		var n = scala.io.StdIn.readInt();
		
		print("SUM: ");
		print(addition(n))
}
	
	
	
	def addition(a:Int):Int={
		if(a==1){
		return 1;
}
		else{
		return a + addition(a-1);
	
}
	
}
     
}