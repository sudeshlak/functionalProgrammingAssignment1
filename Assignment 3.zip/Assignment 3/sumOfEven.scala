object sumOfEven {
  def isEven(x:Int):Boolean={
			if(x==0){
			return true;
		
}
			else if(x==1){
			return false;
}
			else{
			return isEven(x-2);
}


}
  
  def addition(a:Int):Int={
		if(a==0){
		return 0;
}
		else if(isEven(a)){
		return a + addition(a-1);
	
}
		addition(a-1);
	
}
  
  def main(args:Array[String]){
    
    println("Enter a Number:");
		var n = scala.io.StdIn.readInt();
    
    print(addition(n-1));
  }
  
}